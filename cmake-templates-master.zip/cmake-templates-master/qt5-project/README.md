Refs:

-   <http://doc.qt.io/qt-5/cmake-manual.html>
-   <https://github.com/jasondegraw/Qt-CMake-HelloWorld>

-   Windows

    +   <http://whudoc.qiniudn.com/2016/qt-opensource-windows-x86-msvc2015_64-5.6.0.exe>
    +   in CMakeLists.txt, `set( CMAKE_PREFIX_PATH ${CMAKE_PREFIX_PATH} "C:/Qt/VS2015x64/Qt5.6.0/5.6/msvc2015_64" )`
    +   add `C:\Qt\VS2015x64\Qt5.6.0\5.6\msvc2015_64\bin` to %PATH%
