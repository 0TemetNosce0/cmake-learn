double square( double x );
