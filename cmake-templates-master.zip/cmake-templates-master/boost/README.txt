simple cpp with BOOST library support.

You can see a standalone version of this at [district10/bcp-example-1: An exmaple to show how to use bcp.](https://github.com/district10/bcp-example-1).
