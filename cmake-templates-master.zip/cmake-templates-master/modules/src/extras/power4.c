#include "functions.h"

double power4( double x )
{
    return x * x * x * x;
}
