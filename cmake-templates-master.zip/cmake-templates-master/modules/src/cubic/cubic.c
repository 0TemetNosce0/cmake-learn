#include "functions.h"

double cubic( double x )
{
    return x * x * x;
}
