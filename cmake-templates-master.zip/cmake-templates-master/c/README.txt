simple c.
